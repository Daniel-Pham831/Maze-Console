﻿#include "maze.h"


Maze::Maze(int sizeOfMaze, pair<int, int> startValue, pair<int, int> endValue) {
	originalSize = sizeOfMaze;
	size = sizeOfMaze * 2 - 1;
	grid = new int* [size];
	for (int i = 0; i < size; i++) {
		grid[i] = new int[size];
	}

	for (int row = 0; row < size; row++) {
		for (int col = 0; col < size; col++) {
			if (row % 2 == 1) {
				grid[row][col] = WALL;
				continue;
			}
			if (col % 2 == 1) {
				grid[row][col] = WALL;
				continue;
			}
			grid[row][col] = SPACE;
		}
	}
	grid[startValue.first*2][startValue.second*2] = SPACE;
	grid[endValue.first*2][endValue.second*2] = SPACE;
}

Maze::~Maze() {
	for (int i = 0; i < size; i++) {
		delete[] grid[i];
	}
	delete[]grid;
}

void Maze::printDouble(int value) {
	cout << (char)value;
	cout << (char)value;
}

void Maze::show() {
	for (int i = 0; i < size + 2; i++) {
		printDouble(WALL);
	}
	cout << endl;
	for (int row = 0; row < size; row++) {
		printDouble(WALL);
		for (int col = 0; col < size; col++) {
			printDouble(grid[row][col]);
		}
		printDouble(WALL);
		cout << endl;
	}
	for (int i = 0; i < size + 2; i++) {
		printDouble(WALL);
	}
	cout << endl;
}

void Maze::update() {
	Sleep(DELAY);
	clearscreen();
	show();
}

void Maze::makeMaze() {
	map<pair<int, int>, pair<int, int>> visitedCells;
	visitedCells[start] = { 0,0 };
	makeMazeHelper(visitedCells);
	for (auto& key : visitedCells) {
		int tempRow, tempCol;
		tempRow = key.second.first;
		tempCol = key.second.second;
		grid[tempRow][tempCol] = SPACE;
	}
}

void Maze::makeMazeHelper(map<pair<int, int>, pair<int, int>>& visitedCells) {
	pair<int, int> curCell = start;
	pair<int, int> nextCell;
	stack<pair<int, int>> path;
	path.push(curCell);
	while (originalSize*originalSize != visitedCells.size()) {
		//kiểm tra xem cur còn neighbor nào để di ko
		if (chooseNextCell(curCell,nextCell, visitedCells)) {
			pair<int, int> tempWall;

			//tìm cái tường giữa cur và next
			if (curCell.first == nextCell.first) {
				tempWall.first = nextCell.first;
				if (curCell.second > nextCell.second) {
					tempWall.second = curCell.second - 1;
				}
				else {
					tempWall.second = curCell.second + 1;
				}
			}
			else if (curCell.second == nextCell.second) {
				tempWall.second = nextCell.second;
				if (curCell.first > nextCell.first) {
					tempWall.first = curCell.first - 1;
				}
				else {
					tempWall.first = curCell.first + 1;
				}
			}
			visitedCells[nextCell] = tempWall;

			//update để show lên màn hình console
			int tempRow, tempCol;
			tempRow = tempWall.first;
			tempCol = tempWall.second;
			grid[tempRow][tempCol] = SPACE;
			update();



			path.push(nextCell);
			curCell = nextCell;
		}
		else {
			path.pop();
			curCell = path.top();
		}
	}
}

bool Maze::chooseNextCell(pair<int, int> currentCell, pair<int, int>& chosenCell, map<pair<int, int>, pair<int, int>> visitedCells) {
	vector<pair<int, int>> neighbors;

	pair<int, int> up;
	up.first = currentCell.first - 2;
	up.second = currentCell.second;
	neighbors.push_back(up);
	pair<int, int> down;
	down.first = currentCell.first + 2;
	down.second = currentCell.second;
	neighbors.push_back(down);

	pair<int, int> left;
	left.first = currentCell.first;
	left.second = currentCell.second - 2;
	neighbors.push_back(left);

	pair<int, int> right;
	right.first = currentCell.first;
	right.second = currentCell.second + 2;
	neighbors.push_back(right);
	
	//kiểm tra xem có thằng nào ngoài biên hay có trong visited hay chưa
	for (int i = 0; i < neighbors.size(); i++) {
		if (neighbors[i].first < 0 || neighbors[i].first > size || neighbors[i].second < 0 || neighbors[i].second > size) {
			neighbors.erase(neighbors.begin() + i);
			i--;
			continue;
		}
		for (auto& visitedKey : visitedCells) {
			if (visitedKey.first == neighbors[i]) {
				neighbors.erase(neighbors.begin() + i);
				i--;
				break;
			}
		}
	}
	if (neighbors.size() == 0) return false;
	else {

		//random những thằng còn xót trong neighbors rồi return
		int random = (rand()+1) % neighbors.size();
		chosenCell = neighbors[random];
		return true;
	}

}

void Maze::clearscreen() {
	HANDLE hOut;
	COORD Position;

	hOut = GetStdHandle(STD_OUTPUT_HANDLE);

	Position.X = 0;
	Position.Y = 0;
	SetConsoleCursorPosition(hOut, Position);
}