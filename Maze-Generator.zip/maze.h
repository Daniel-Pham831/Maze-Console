#pragma once
#include <iostream>
#include <vector>
#include <map>
#include <stack>
#include <set>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>

const int SPACE = 32;
const int WALL = 219;
const int DELAY = 10;


using namespace std;

class Maze {
public:
	
	Maze(int sizeOfMaze,pair<int,int> startValue,pair<int,int> endValue);
	~Maze();
	void show();
	void makeMaze();
	

	

	
private:
	int size;
	int originalSize;
	int** grid;
	pair<int, int> start;
	pair<int, int> end;

	bool chooseNextCell(pair<int, int> currentCell, pair<int, int>& chosenCell, map<pair<int, int>, pair<int, int>> visitedCells);
	void makeMazeHelper(map<pair<int, int>, pair<int, int>>& visitedCells);
	void printDouble(int value);
	void update();
	void clearscreen();
};


