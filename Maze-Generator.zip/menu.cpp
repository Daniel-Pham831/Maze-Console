#include "menu.h"
#include "maze.h"


void menu() {
	system("cls");
	int n;
	int op;
	
	while (true) {
		srand(time(0));
		cout << "Vui long nhap do lon cua Maze: ";
		cin >> op;
		pair<int, int> start = { 0,0 };
		pair<int, int> end = { op-1, op-1 };

		Maze test(op, start, end);
		system("cls");
		test.show();
		test.makeMaze();
		cout << "============MENU============" << endl;
		cout << "1: Re-Maze\n";
		cout << "-99:Exit\n";
		cin >> n;
		if (n == 1) {
			continue;
		}
		else {
			break;
		}
	}
}