#include <iostream>

using namespace std;

void menu();